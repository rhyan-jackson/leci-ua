Please, run this script in maximized window (graphic porpouses).

If you don't have any of these modules used on the script, please do pip install {module}, with '{module}' as the is not installed in your python.
 
