import java.util.Scanner;

public class ex5 {

    public static String centerText(String text, int maxChar) {
        if (maxChar - text.length() <= 0) {
            return text;
        } 
        String formattedString = "";
        double paddingNum = ((double)maxChar - (double)text.length()) / 2;
        String padding1 = "-".repeat((int)Math.floor(paddingNum));
        String padding2 = "-".repeat((int)Math.ceil(paddingNum));
        formattedString = String.format("%s%s%s", padding1, text, padding2);

        return formattedString;
    }

    public static void printCalendar(String date, int firstMonthDay) {
        String[] monthArray = {"January", "February", "March", "April", "May", "June",
                       "July", "August", "September", "October", "November", "December"};

        System.out.println(centerText(month + " " + year, 20));
        System.out.println("Su Mo Tu We Th Fr Sa");
        for ()
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
    }
}