package ex10_1e2;

public class MainTest {
    public static void main(String[] args) {
        GenderMap genderMap = new GenderMap();
        System.out.println(genderMap);
    }
}
