package ex02;

public class DateND extends Date {

}