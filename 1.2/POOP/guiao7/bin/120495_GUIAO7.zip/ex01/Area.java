package ex01;

public interface Area {
    double calculateArea();

}
