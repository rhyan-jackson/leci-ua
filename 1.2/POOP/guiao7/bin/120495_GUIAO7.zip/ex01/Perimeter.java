package ex01;

public interface Perimeter {
    public double calculatePerimeter();
}
